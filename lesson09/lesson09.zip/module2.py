# -*- coding: utf-8 -*-
"""
Created on: 21.07.25 17:23
@author: Dmytro Nikolaenko (nikodim74@gmail.com)
@user: d.nikolaenko
@project name: Python3_courses_homework
@file: module2.py
"""
from module1 import greet

def run():
    """Імпортуємо greet і використовуємо її"""
    print(greet("Ніко"))
