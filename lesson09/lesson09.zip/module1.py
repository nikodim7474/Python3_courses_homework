# -*- coding: utf-8 -*-
"""
Created on: 21.07.25 17:22
@author: Dmytro Nikolaenko (nikodim74@gmail.com)
@user: d.nikolaenko
@project name: Python3_courses_homework
@file: module1.py
"""
def greet(name):
    """Проста функція для привітання"""
    return f"Привіт, {name}! Це функція з module1."
